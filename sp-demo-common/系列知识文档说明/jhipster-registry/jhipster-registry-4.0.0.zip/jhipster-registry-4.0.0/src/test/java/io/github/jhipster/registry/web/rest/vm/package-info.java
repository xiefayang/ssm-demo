/**
 * Tests of View Models used by Spring MVC REST controllers.
 */
package io.github.jhipster.registry.web.rest.vm;
