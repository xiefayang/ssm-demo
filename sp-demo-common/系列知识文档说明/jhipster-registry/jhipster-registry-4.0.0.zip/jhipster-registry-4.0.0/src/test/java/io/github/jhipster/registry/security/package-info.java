package io.github.jhipster.registry.security;
