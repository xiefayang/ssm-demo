export class Log {
    constructor(public name: string, public level: string) {}
}
