package io.github.jhipster.registry.config;

public class Constants {

    public static final String PROFILE_OAUTH2 = "oauth2";

    private Constants() {
    }
}
